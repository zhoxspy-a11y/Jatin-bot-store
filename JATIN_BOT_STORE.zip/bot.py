import asyncio
import logging
import os
import sqlite3
from datetime import datetime
from typing import Optional

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode, ContentType
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton, FSInputFile
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

# =========================
# CONFIG
# =========================
BOT_TOKEN = os.getenv("BOT_TOKEN", "8988037238:AAGOZt9FPC6ZXcSEZpq-bb-SOk6vjEQYVdY")

# Put one or more Telegram numeric user IDs here, comma separated.
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "8894084046").split(",")
    if x.strip().isdigit()
}

SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "@NovaHacker07")
STORE_NAME = "JATIN STORE"
PAYMENT_ID = os.getenv("PAYMENT_ID", "jatinmishra123@fam")
PAYMENT_QR_FILE = os.getenv("PAYMENT_QR_FILE", "payment_qr.jpg")
DB_PATH = os.getenv("DB_PATH", "data/jatin_store.db")

MIN_ADD_BALANCE = 10
ORDER_PROCESSING_TEXT = "40–50 minutes"

logging.basicConfig(level=logging.INFO)
dp = Dispatcher()


# =========================
# DATABASE
# =========================
def db():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_id INTEGER UNIQUE NOT NULL,
            username TEXT,
            first_name TEXT,
            balance REAL NOT NULL DEFAULT 0,
            banned INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            quantity TEXT NOT NULL,
            requirement TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_id INTEGER NOT NULL,
            service_id INTEGER NOT NULL,
            service_name TEXT NOT NULL,
            platform TEXT NOT NULL,
            price REAL NOT NULL,
            target TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'accepted',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS deposits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            screenshot_file_id TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """)

        defaults = {
            "payment_id": PAYMENT_ID,
            "payment_text": "FamPay / UPI",
            "processing_time": ORDER_PROCESSING_TEXT,
        }
        for k, v in defaults.items():
            con.execute(
                "INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v)
            )

        count = con.execute("SELECT COUNT(*) AS c FROM services").fetchone()["c"]
        if count == 0:
            services = [
                ("Instagram", "1K Instagram Followers", 40, "1K", "Instagram profile link"),
                ("Instagram", "2K Instagram Followers", 75, "2K", "Instagram profile link"),
                ("Instagram", "3K Instagram Followers", 100, "3K", "Instagram profile link"),
                ("YouTube", "1K YouTube Subscribers", 29, "1K", "YouTube channel link"),
                ("YouTube", "100K YouTube Views", 40, "100K", "YouTube video link"),
                ("YouTube", "10K YouTube Likes", 10, "10K", "YouTube video link"),
                ("YouTube", "1K YouTube Views", 49, "1K", "YouTube video link"),
                ("Facebook", "1K Facebook Followers", 50, "1K", "Facebook profile/page link"),
            ]
            con.executemany("""
                INSERT INTO services(platform,name,price,quantity,requirement)
                VALUES(?,?,?,?,?)
            """, services)


def upsert_user(message: Message):
    with db() as con:
        con.execute("""
            INSERT INTO users(tg_id,username,first_name,created_at)
            VALUES(?,?,?,?)
            ON CONFLICT(tg_id) DO UPDATE SET
                username=excluded.username,
                first_name=excluded.first_name
        """, (
            message.from_user.id,
            message.from_user.username,
            message.from_user.first_name,
            datetime.utcnow().isoformat(timespec="seconds")
        ))


def get_user(tg_id: int):
    with db() as con:
        return con.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()


def is_banned(tg_id: int) -> bool:
    row = get_user(tg_id)
    return bool(row and row["banned"])


def setting(key: str) -> str:
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else ""


def set_setting(key: str, value: str):
    with db() as con:
        con.execute("""
            INSERT INTO settings(key,value) VALUES(?,?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value
        """, (key, value))


def money(x: float) -> str:
    return f"₹{x:g}"


# =========================
# KEYBOARDS
# =========================
def main_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="💰 ADD BALANCE"), KeyboardButton(text="👤 MY ACCOUNT")],
            [KeyboardButton(text="🛒 BUY SERVICE"), KeyboardButton(text="📋 ALL SERVICE")],
        ],
        resize_keyboard=True
    )


def platform_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📸 TG"), KeyboardButton(text="📸 INSTA")],
            [KeyboardButton(text="▶️ YT"), KeyboardButton(text="📘 FB")],
            [KeyboardButton(text="🔙 BACK")],
        ],
        resize_keyboard=True
    )


def admin_kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 TOTAL USERS"), KeyboardButton(text="🚫 USERS BAN")],
            [KeyboardButton(text="♻️ USERS UNBAN"), KeyboardButton(text="💳 BALANCE APPROVE")],
            [KeyboardButton(text="❌ BALANCE REJECT"), KeyboardButton(text="➕ ADD SERVICE")],
            [KeyboardButton(text="🗑 DELETE SERVICE"), KeyboardButton(text="💰 PAYMENT SYSTEM")],
            [KeyboardButton(text="📦 ORDERS"), KeyboardButton(text="📋 SERVICE LIST")],
            [KeyboardButton(text="🔙 USER MENU")],
        ],
        resize_keyboard=True
    )


def service_inline(platform: str):
    with db() as con:
        rows = con.execute("""
            SELECT * FROM services
            WHERE platform=? AND active=1 ORDER BY id
        """, (platform,)).fetchall()

    kb = InlineKeyboardBuilder()
    for s in rows:
        kb.button(
            text=f"{s['name']} — {money(s['price'])}",
            callback_data=f"service:{s['id']}"
        )
    kb.adjust(1)
    return kb.as_markup()


def deposit_admin_inline(dep_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ APPROVE", callback_data=f"dep_ok:{dep_id}"),
            InlineKeyboardButton(text="❌ REJECT", callback_data=f"dep_no:{dep_id}")
        ]
    ])


# =========================
# FSM
# =========================
class DepositStates(StatesGroup):
    amount = State()
    screenshot = State()


class OrderStates(StatesGroup):
    target = State()


class AddServiceStates(StatesGroup):
    platform = State()
    name = State()
    price = State()
    quantity = State()
    requirement = State()


class BanStates(StatesGroup):
    tg_id = State()


class PaymentStates(StatesGroup):
    payment_id = State()
    payment_text = State()


# =========================
# HELPERS
# =========================
async def guard(message: Message) -> bool:
    upsert_user(message)
    if is_banned(message.from_user.id):
        await message.answer("🚫 Your account is currently banned. Please contact support.")
        return False
    return True


async def send_admins(bot: Bot, text: str, reply_markup=None):
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, text, reply_markup=reply_markup)
        except Exception as e:
            logging.warning("Admin notification failed for %s: %s", admin_id, e)


# =========================
# USER START / MENU
# =========================
@dp.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    if not await guard(message):
        return
    text = (
        f"✨ <b>WELCOME TO {STORE_NAME}</b> ✨\n\n"
        "Your one-stop destination for <b>Social Media Services</b>.\n\n"
        "🚀 Instagram • YouTube • Facebook\n"
        "💎 Fast order processing\n"
        "💰 Easy balance system\n"
        "🛡️ Manual payment verification\n\n"
        "Use the buttons below to check services, add balance, "
        "or place an order.\n\n"
        f"🆘 <b>Support:</b> {SUPPORT_USERNAME}"
    )
    await message.answer(text, reply_markup=main_kb())


@dp.message(F.text == "👤 MY ACCOUNT")
async def my_account(message: Message):
    if not await guard(message):
        return
    u = get_user(message.from_user.id)
    await message.answer(
        "👤 <b>MY ACCOUNT</b>\n\n"
        f"🆔 User ID: <code>{u['tg_id']}</code>\n"
        f"👤 Username: @{u['username'] or 'Not set'}\n"
        f"💰 Balance: <b>{money(u['balance'])}</b>\n"
        f"📅 Joined: {u['created_at'][:10]}",
        reply_markup=main_kb()
    )


@dp.message(F.text == "📋 ALL SERVICE")
async def all_services(message: Message):
    if not await guard(message):
        return
    with db() as con:
        rows = con.execute("""
            SELECT * FROM services WHERE active=1 ORDER BY
            CASE platform
                WHEN 'Instagram' THEN 1
                WHEN 'YouTube' THEN 2
                WHEN 'Facebook' THEN 3
                ELSE 4
            END, id
        """).fetchall()

    if not rows:
        await message.answer("⚠️ No active services are available right now.")
        return

    lines = ["📋 <b>ALL AVAILABLE SERVICES</b>\n"]
    current = None
    for s in rows:
        if s["platform"] != current:
            current = s["platform"]
            lines.append(f"\n<b>━━ {current} ━━</b>")
        lines.append(f"• {s['name']} — <b>{money(s['price'])}</b>")
    lines.append(f"\n🆘 Support: {SUPPORT_USERNAME}")
    await message.answer("\n".join(lines), reply_markup=main_kb())


@dp.message(F.text == "🛒 BUY SERVICE")
async def buy_service(message: Message, state: FSMContext):
    if not await guard(message):
        return
    await state.clear()
    await message.answer(
        "🛒 <b>SELECT PLATFORM</b>\n\n"
        "Choose the platform for your service:",
        reply_markup=platform_kb()
    )


@dp.message(F.text == "🔙 BACK")
async def back_to_menu(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("🏠 Main menu", reply_markup=main_kb())


# =========================
# PLATFORM → SERVICE LIST
# =========================
async def show_platform_services(message: Message, platform: str):
    if not await guard(message):
        return
    with db() as con:
        count = con.execute(
            "SELECT COUNT(*) AS c FROM services WHERE platform=? AND active=1",
            (platform,)
        ).fetchone()["c"]

    if count == 0:
        await message.answer(
            f"⚠️ No {platform} service is available right now.",
            reply_markup=platform_kb()
        )
        return

    await message.answer(
        f"📦 <b>{platform.upper()} SERVICES</b>\n\n"
        "Select a service below:",
        reply_markup=service_inline(platform)
    )


@dp.message(F.text == "📸 TG")
async def tg_services(message: Message):
    await show_platform_services(message, "Telegram")


@dp.message(F.text == "📸 INSTA")
async def insta_services(message: Message):
    await show_platform_services(message, "Instagram")


@dp.message(F.text == "▶️ YT")
async def yt_services(message: Message):
    await show_platform_services(message, "YouTube")


@dp.message(F.text == "📘 FB")
async def fb_services(message: Message):
    await show_platform_services(message, "Facebook")


@dp.callback_query(F.data.startswith("service:"))
async def select_service(call: CallbackQuery, state: FSMContext):
    if is_banned(call.from_user.id):
        await call.answer("Account banned.", show_alert=True)
        return

    sid = int(call.data.split(":")[1])
    with db() as con:
        s = con.execute(
            "SELECT * FROM services WHERE id=? AND active=1", (sid,)
        ).fetchone()

    if not s:
        await call.answer("Service unavailable.", show_alert=True)
        return

    await state.update_data(service_id=sid)
    await state.set_state(OrderStates.target)
    await call.message.answer(
        "🛒 <b>ORDER DETAILS</b>\n\n"
        f"📦 Service: <b>{s['name']}</b>\n"
        f"🔢 Quantity: <b>{s['quantity']}</b>\n"
        f"💵 Price: <b>{money(s['price'])}</b>\n\n"
        f"🔗 Please send your <b>{s['requirement']}</b>.\n"
        "Example: https://...\n\n"
        "Send /cancel to cancel this order."
    )
    await call.answer()


@dp.message(OrderStates.target)
async def receive_target(message: Message, state: FSMContext, bot: Bot):
    if not await guard(message):
        return
    if message.text and message.text.lower() == "/cancel":
        await state.clear()
        await message.answer("❌ Order cancelled.", reply_markup=main_kb())
        return

    data = await state.get_data()
    sid = data.get("service_id")
    with db() as con:
        s = con.execute(
            "SELECT * FROM services WHERE id=? AND active=1", (sid,)
        ).fetchone()
        u = con.execute(
            "SELECT * FROM users WHERE tg_id=?", (message.from_user.id,)
        ).fetchone()

    if not s:
        await state.clear()
        await message.answer("⚠️ Service is no longer available.", reply_markup=main_kb())
        return

    target = (message.text or "").strip()
    if not target:
        await message.answer("❗ Please send a valid link/ID.")
        return

    if float(u["balance"]) < float(s["price"]):
        await state.clear()
        await message.answer(
            "❌ <b>INSUFFICIENT BALANCE</b>\n\n"
            f"Required: <b>{money(s['price'])}</b>\n"
            f"Your balance: <b>{money(u['balance'])}</b>\n\n"
            "Please use <b>ADD BALANCE</b> first.",
            reply_markup=main_kb()
        )
        return

    with db() as con:
        con.execute(
            "UPDATE users SET balance=balance-? WHERE tg_id=?",
            (s["price"], message.from_user.id)
        )
        cur = con.execute("""
            INSERT INTO orders(tg_id,service_id,service_name,platform,price,target,status,created_at)
            VALUES(?,?,?,?,?,?,?,?)
        """, (
            message.from_user.id, s["id"], s["name"], s["platform"],
            s["price"], target, "accepted",
            datetime.utcnow().isoformat(timespec="seconds")
        ))
        order_id = cur.lastrowid

    await state.clear()
    await message.answer(
        "✅ <b>ORDER ACCEPTED</b>\n\n"
        f"🆔 Order ID: <code>#{order_id}</code>\n"
        f"📦 Service: <b>{s['name']}</b>\n"
        f"💵 Price: <b>{money(s['price'])}</b>\n"
        f"🔗 Link: <code>{target}</code>\n\n"
        f"⏱️ Estimated processing time: <b>{setting('processing_time')}</b>\n"
        "Please don't change the target during processing.\n\n"
        f"🆘 Support: {SUPPORT_USERNAME}",
        reply_markup=main_kb()
    )

    await send_admins(
        bot,
        "📦 <b>NEW ORDER</b>\n\n"
        f"🆔 Order: #{order_id}\n"
        f"👤 User: <code>{message.from_user.id}</code> "
        f"@{message.from_user.username or 'N/A'}\n"
        f"📦 {s['name']}\n"
        f"💵 {money(s['price'])}\n"
        f"🔗 {target}"
    )


# =========================
# ADD BALANCE
# =========================
@dp.message(F.text == "💰 ADD BALANCE")
async def add_balance(message: Message, state: FSMContext):
    if not await guard(message):
        return
    await state.clear()
    await state.set_state(DepositStates.amount)

    pay_id = setting("payment_id")
    pay_text = setting("payment_text")

    if os.path.exists(PAYMENT_QR_FILE):
        await message.answer_photo(
            FSInputFile(PAYMENT_QR_FILE),
            caption=(
                "💳 <b>ADD BALANCE</b>\n\n"
                f"Payment Method: <b>{pay_text}</b>\n"
                f"Payment ID: <code>{pay_id}</code>\n\n"
                f"Minimum: <b>{money(MIN_ADD_BALANCE)}</b>\n\n"
                "First send the amount you want to add.\n"
                "Example: <code>100</code>"
            )
        )
    else:
        await message.answer(
            "💳 <b>ADD BALANCE</b>\n\n"
            f"Payment Method: <b>{pay_text}</b>\n"
            f"Payment ID: <code>{pay_id}</code>\n\n"
            f"Minimum: <b>{money(MIN_ADD_BALANCE)}</b>\n\n"
            "Send the amount you want to add.\n"
            "Example: <code>100</code>"
        )


@dp.message(DepositStates.amount)
async def deposit_amount(message: Message, state: FSMContext):
    try:
        amount = float(message.text.replace(",", "").strip())
    except Exception:
        await message.answer("❗ Send only the amount. Example: 100")
        return

    if amount < MIN_ADD_BALANCE:
        await message.answer(f"❗ Minimum amount is {money(MIN_ADD_BALANCE)}.")
        return

    await state.update_data(amount=amount)
    await state.set_state(DepositStates.screenshot)

    await message.answer(
        f"💰 Amount: <b>{money(amount)}</b>\n\n"
        f"Pay <b>{money(amount)}</b> to:\n"
        f"<code>{setting('payment_id')}</code>\n\n"
        "After payment, send the <b>payment screenshot</b> here.\n"
        "Verification usually takes up to 5 minutes."
    )


@dp.message(DepositStates.screenshot, F.content_type == ContentType.PHOTO)
async def deposit_screenshot(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    amount = float(data["amount"])

    with db() as con:
        cur = con.execute("""
            INSERT INTO deposits(tg_id,amount,screenshot_file_id,status,created_at)
            VALUES(?,?,?,?,?)
        """, (
            message.from_user.id, amount, message.photo[-1].file_id,
            "pending", datetime.utcnow().isoformat(timespec="seconds")
        ))
        dep_id = cur.lastrowid

    await state.clear()
    await message.answer(
        "⏳ <b>PAYMENT VERIFICATION PROCESSING</b>\n\n"
        f"Amount: <b>{money(amount)}</b>\n"
        "Status: <b>WAIT ~5 MIN</b>\n\n"
        "Your payment screenshot has been sent to the admin for verification.",
        reply_markup=main_kb()
    )

    admin_text = (
        "💳 <b>NEW BALANCE REQUEST</b>\n\n"
        f"🆔 Request: #{dep_id}\n"
        f"👤 User ID: <code>{message.from_user.id}</code>\n"
        f"👤 Username: @{message.from_user.username or 'N/A'}\n"
        f"💰 Amount: <b>{money(amount)}</b>\n"
        f"🕒 {datetime.utcnow().isoformat(timespec='seconds')} UTC"
    )
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_photo(
                admin_id,
                message.photo[-1].file_id,
                caption=admin_text,
                reply_markup=deposit_admin_inline(dep_id)
            )
        except Exception as e:
            logging.warning("Deposit admin notification failed: %s", e)


@dp.message(DepositStates.screenshot)
async def deposit_wrong_type(message: Message):
    await message.answer("❗ Please send the payment screenshot as an image/photo.")


@dp.callback_query(F.data.startswith("dep_ok:"))
async def approve_deposit(call: CallbackQuery, bot: Bot):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Not authorized.", show_alert=True)
        return

    dep_id = int(call.data.split(":")[1])
    with db() as con:
        dep = con.execute("SELECT * FROM deposits WHERE id=?", (dep_id,)).fetchone()
        if not dep or dep["status"] != "pending":
            await call.answer("Already processed.", show_alert=True)
            return

        con.execute(
            "UPDATE deposits SET status='approved' WHERE id=?", (dep_id,)
        )
        con.execute(
            "UPDATE users SET balance=balance+? WHERE tg_id=?",
            (dep["amount"], dep["tg_id"])
        )
        user = con.execute(
            "SELECT balance FROM users WHERE tg_id=?", (dep["tg_id"],)
        ).fetchone()

    await call.message.edit_reply_markup(reply_markup=None)
    await call.message.answer(f"✅ Deposit #{dep_id} approved.")
    await bot.send_message(
        dep["tg_id"],
        "✅ <b>BALANCE ADDED SUCCESSFULLY</b>\n\n"
        f"💰 Added: <b>{money(dep['amount'])}</b>\n"
        f"💳 New Balance: <b>{money(user['balance'])}</b>",
        reply_markup=main_kb()
    )
    await call.answer("Approved.")


@dp.callback_query(F.data.startswith("dep_no:"))
async def reject_deposit(call: CallbackQuery, bot: Bot):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("Not authorized.", show_alert=True)
        return

    dep_id = int(call.data.split(":")[1])
    with db() as con:
        dep = con.execute("SELECT * FROM deposits WHERE id=?", (dep_id,)).fetchone()
        if not dep or dep["status"] != "pending":
            await call.answer("Already processed.", show_alert=True)
            return
        con.execute(
            "UPDATE deposits SET status='rejected' WHERE id=?", (dep_id,)
        )

    await call.message.edit_reply_markup(reply_markup=None)
    await call.message.answer(f"❌ Deposit #{dep_id} rejected.")
    await bot.send_message(
        dep["tg_id"],
        "❌ <b>PAYMENT REJECTED</b>\n\n"
        f"Request: #{dep_id}\n"
        "Please contact support if you believe this was a mistake.",
        reply_markup=main_kb()
    )
    await call.answer("Rejected.")


# =========================
# ADMIN
# =========================
def admin_only(message: Message) -> bool:
    return message.from_user.id in ADMIN_IDS


@dp.message(Command("admin"))
async def admin_command(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    await state.clear()
    await message.answer("🛠️ <b>JATIN STORE ADMIN PANEL</b>", reply_markup=admin_kb())


@dp.message(F.text == "🔙 USER MENU")
async def user_menu(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    await state.clear()
    await message.answer("🏠 User menu", reply_markup=main_kb())


@dp.message(F.text == "📊 TOTAL USERS")
async def total_users(message: Message):
    if not admin_only(message):
        return
    with db() as con:
        total = con.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
        banned = con.execute("SELECT COUNT(*) AS c FROM users WHERE banned=1").fetchone()["c"]
        bal = con.execute("SELECT COALESCE(SUM(balance),0) AS b FROM users").fetchone()["b"]
    await message.answer(
        "📊 <b>STORE STATISTICS</b>\n\n"
        f"👥 Total Users: <b>{total}</b>\n"
        f"🚫 Banned: <b>{banned}</b>\n"
        f"💰 User Balance Liability: <b>{money(bal)}</b>"
    )


@dp.message(F.text == "🚫 USERS BAN")
async def ban_start(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    await state.set_state(BanStates.tg_id)
    await state.update_data(action="ban")
    await message.answer("Send the Telegram numeric user ID to ban.")


@dp.message(F.text == "♻️ USERS UNBAN")
async def unban_start(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    await state.set_state(BanStates.tg_id)
    await state.update_data(action="unban")
    await message.answer("Send the Telegram numeric user ID to unban.")


@dp.message(BanStates.tg_id)
async def ban_action(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    if not message.text or not message.text.isdigit():
        await message.answer("❗ Send a numeric Telegram user ID.")
        return
    tg_id = int(message.text)
    data = await state.get_data()
    action = data.get("action")

    with db() as con:
        exists = con.execute("SELECT 1 FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not exists:
            await message.answer("User not found in database.")
            await state.clear()
            return
        con.execute(
            "UPDATE users SET banned=? WHERE tg_id=?",
            (1 if action == "ban" else 0, tg_id)
        )

    await state.clear()
    await message.answer(
        f"✅ User <code>{tg_id}</code> has been "
        f"{'banned' if action == 'ban' else 'unbanned'}."
    )


@dp.message(F.text == "💳 BALANCE APPROVE")
async def pending_deposits(message: Message):
    if not admin_only(message):
        return
    with db() as con:
        rows = con.execute("""
            SELECT * FROM deposits WHERE status='pending'
            ORDER BY id DESC LIMIT 20
        """).fetchall()

    if not rows:
        await message.answer("✅ No pending balance requests.")
        return

    for d in rows:
        await message.answer(
            f"💳 <b>Pending #{d['id']}</b>\n"
            f"User: <code>{d['tg_id']}</code>\n"
            f"Amount: <b>{money(d['amount'])}</b>",
            reply_markup=deposit_admin_inline(d["id"])
        )


@dp.message(F.text == "❌ BALANCE REJECT")
async def rejected_deposits(message: Message):
    if not admin_only(message):
        return
    with db() as con:
        rows = con.execute("""
            SELECT * FROM deposits WHERE status='pending'
            ORDER BY id DESC LIMIT 20
        """).fetchall()
    if not rows:
        await message.answer("No pending requests.")
        return
    await message.answer(
        "Use the inline ❌ REJECT button on each pending request."
    )


@dp.message(F.text == "📋 SERVICE LIST")
async def service_list_admin(message: Message):
    if not admin_only(message):
        return
    with db() as con:
        rows = con.execute("SELECT * FROM services ORDER BY id").fetchall()
    if not rows:
        await message.answer("No services.")
        return
    lines = ["📋 <b>ALL SERVICES</b>\n"]
    for s in rows:
        status = "ON" if s["active"] else "OFF"
        lines.append(
            f"#{s['id']} • {s['platform']} • {s['name']} • "
            f"{money(s['price'])} • {status}"
        )
    await message.answer("\n".join(lines))


@dp.message(F.text == "➕ ADD SERVICE")
async def add_service_start(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    await state.clear()
    await state.set_state(AddServiceStates.platform)
    await message.answer(
        "Enter platform exactly like:\n"
        "<code>Instagram</code>, <code>YouTube</code>, "
        "<code>Facebook</code>, or <code>Telegram</code>"
    )


@dp.message(AddServiceStates.platform)
async def add_service_platform(message: Message, state: FSMContext):
    await state.update_data(platform=message.text.strip())
    await state.set_state(AddServiceStates.name)
    await message.answer("Send service name. Example: 5K Instagram Followers")


@dp.message(AddServiceStates.name)
async def add_service_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(AddServiceStates.price)
    await message.answer("Send price in ₹. Example: 150")


@dp.message(AddServiceStates.price)
async def add_service_price(message: Message, state: FSMContext):
    try:
        price = float(message.text.strip())
    except Exception:
        await message.answer("Send a valid numeric price.")
        return
    await state.update_data(price=price)
    await state.set_state(AddServiceStates.quantity)
    await message.answer("Send quantity label. Example: 5K")


@dp.message(AddServiceStates.quantity)
async def add_service_quantity(message: Message, state: FSMContext):
    await state.update_data(quantity=message.text.strip())
    await state.set_state(AddServiceStates.requirement)
    await message.answer(
        "What should the customer send?\n"
        "Example: Instagram profile link / YouTube video link"
    )


@dp.message(AddServiceStates.requirement)
async def add_service_requirement(message: Message, state: FSMContext):
    data = await state.get_data()
    with db() as con:
        cur = con.execute("""
            INSERT INTO services(platform,name,price,quantity,requirement)
            VALUES(?,?,?,?,?)
        """, (
            data["platform"], data["name"], data["price"],
            data["quantity"], message.text.strip()
        ))
        sid = cur.lastrowid
    await state.clear()
    await message.answer(f"✅ Service #{sid} added successfully.", reply_markup=admin_kb())


@dp.message(F.text == "🗑 DELETE SERVICE")
async def delete_service(message: Message):
    if not admin_only(message):
        return
    await message.answer(
        "To disable a service, send:\n"
        "<code>/delservice SERVICE_ID</code>\n\n"
        "To enable it again:\n"
        "<code>/onservice SERVICE_ID</code>"
    )


@dp.message(Command("delservice"))
async def del_service(message: Message):
    if not admin_only(message):
        return
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Usage: /delservice 12")
        return
    sid = int(parts[1])
    with db() as con:
        con.execute("UPDATE services SET active=0 WHERE id=?", (sid,))
    await message.answer(f"✅ Service #{sid} disabled.")


@dp.message(Command("onservice"))
async def on_service(message: Message):
    if not admin_only(message):
        return
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Usage: /onservice 12")
        return
    sid = int(parts[1])
    with db() as con:
        con.execute("UPDATE services SET active=1 WHERE id=?", (sid,))
    await message.answer(f"✅ Service #{sid} enabled.")


@dp.message(F.text == "💰 PAYMENT SYSTEM")
async def payment_system(message: Message, state: FSMContext):
    if not admin_only(message):
        return
    await state.set_state(PaymentStates.payment_id)
    await message.answer(
        "💰 <b>PAYMENT SETTINGS</b>\n\n"
        f"Current Payment ID: <code>{setting('payment_id')}</code>\n"
        f"Current Method: <b>{setting('payment_text')}</b>\n\n"
        "Send the new payment ID (UPI/FamPay/etc.)."
    )


@dp.message(PaymentStates.payment_id)
async def payment_id_update(message: Message, state: FSMContext):
    set_setting("payment_id", message.text.strip())
    await state.set_state(PaymentStates.payment_text)
    await message.answer(
        "Now send the payment method name.\n"
        "Example: <code>FamPay / UPI</code>"
    )


@dp.message(PaymentStates.payment_text)
async def payment_text_update(message: Message, state: FSMContext):
    set_setting("payment_text", message.text.strip())
    await state.clear()
    await message.answer(
        "✅ Payment system updated.\n\n"
        f"Method: <b>{setting('payment_text')}</b>\n"
        f"ID: <code>{setting('payment_id')}</code>",
        reply_markup=admin_kb()
    )


@dp.message(F.text == "📦 ORDERS")
async def orders_admin(message: Message):
    if not admin_only(message):
        return
    with db() as con:
        rows = con.execute("""
            SELECT * FROM orders ORDER BY id DESC LIMIT 20
        """).fetchall()
    if not rows:
        await message.answer("No orders yet.")
        return

    lines = ["📦 <b>RECENT ORDERS</b>\n"]
    for o in rows:
        lines.append(
            f"#{o['id']} • {o['platform']} • {o['service_name']}\n"
            f"User: <code>{o['tg_id']}</code> • {money(o['price'])} • {o['status']}\n"
            f"Target: {o['target']}\n"
        )
    await message.answer("\n".join(lines))


# =========================
# ADMIN COMMANDS
# =========================
@dp.message(Command("broadcast"))
async def broadcast(message: Message, bot: Bot):
    if not admin_only(message):
        return
    text = message.text.partition(" ")[2].strip()
    if not text:
        await message.answer("Usage: /broadcast Your message")
        return

    with db() as con:
        users = con.execute("SELECT tg_id FROM users WHERE banned=0").fetchall()

    sent = 0
    for u in users:
        try:
            await bot.send_message(u["tg_id"], text)
            sent += 1
        except Exception:
            pass
    await message.answer(f"📢 Broadcast finished. Sent: {sent}/{len(users)}")


@dp.message(Command("users"))
async def users_cmd(message: Message):
    if not admin_only(message):
        return
    with db() as con:
        rows = con.execute("""
            SELECT tg_id,username,balance,banned,created_at
            FROM users ORDER BY id DESC LIMIT 50
        """).fetchall()

    if not rows:
        await message.answer("No users.")
        return

    lines = ["👥 <b>RECENT USERS</b>\n"]
    for u in rows:
        lines.append(
            f"<code>{u['tg_id']}</code> • @{u['username'] or 'N/A'} • "
            f"{money(u['balance'])} • {'BANNED' if u['banned'] else 'ACTIVE'}"
        )
    await message.answer("\n".join(lines))


# =========================
# FALLBACK
# =========================
@dp.message()
async def fallback(message: Message):
    if not await guard(message):
        return
    await message.answer(
        "Please use the menu buttons below.",
        reply_markup=main_kb()
    )


async def main():
    if BOT_TOKEN == "PASTE_BOT_TOKEN_HERE":
        raise RuntimeError("Set BOT_TOKEN environment variable before running.")

    init_db()
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    logging.info("JATIN STORE bot is running...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
